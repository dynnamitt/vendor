== Saving procedure for icon files ==

A wise man once said: "256 colors should be enough for everyone."

PNG images consume lots of memory in Internet Explorer. To prevent skewed
memory usage comparisons we won't use PNG's unless absolutely necessary.

Photoshop
 > File
   > Save for web
     - File format: GIF
     - Color reduction algorithm: Selective
     - Dither algorithm: Diffusion
     - Transparency: enabled
     - Transparency dither: disabled
     - Interlaced: disabled
     - Lossy: 0
     - Colors: 256
     - Dither: 88%
     - Matte: none
     - Web snap: 0

These export presets have been exported to the "gif-settings" file.