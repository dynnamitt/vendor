IO.setSaveXMLFunction(function(uri, doc) {
  alert("This is just a demo, so no actual saving is performed.");
});
